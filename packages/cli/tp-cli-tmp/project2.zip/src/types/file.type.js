"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.File = void 0;
class File {
}
exports.File = File;
//# sourceMappingURL=file.type.js.map
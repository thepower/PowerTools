export declare class CliConfig {
    source: string;
    address: string;
    projectId: string;
    wif: string;
}

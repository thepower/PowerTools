export declare const getFileHash: (filePath: string) => Promise<string>;
export declare const getHash: (jsonString: string) => string;

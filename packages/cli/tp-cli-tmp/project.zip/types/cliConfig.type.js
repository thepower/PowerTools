"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.CliConfig = void 0;
class CliConfig {
}
exports.CliConfig = CliConfig;
//# sourceMappingURL=cliConfig.type.js.map
export declare class File {
    name: string;
    path: string;
    hash: string;
    size: number;
}

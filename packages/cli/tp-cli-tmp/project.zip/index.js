"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.run = void 0;
var core_1 = require("@oclif/core");
Object.defineProperty(exports, "run", { enumerable: true, get: function () { return core_1.run; } });
//# sourceMappingURL=index.js.map
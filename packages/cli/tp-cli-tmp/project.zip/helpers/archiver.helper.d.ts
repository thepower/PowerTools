export declare const createDirIfNotExists: (dir: string) => void;
export declare const archiveDir: (sourceDir: string) => Promise<any>;
